import { Field, Formik, Form, ErrorMessage } from "formik";
import React from "react";
import * as Yup from 'yup';
import AuthService from '../modules/authservice'

// import styles from './Register.module.css'
function Register() {
    return (
      <div className="maindiv">
    <div className="home">
    <div className="pic">
        <h1><center>Register</center></h1>
        {/* <p>Volup amet magna clita tempor. Tempor sea eos vero ipsum. Lorem lorem sit sed elitr sed kasd et</p> */}
    </div>
  <div className="container" >
    <div className="page">
      {/* <div className={styles.reg} */}
    <div>
        <Formik
        initialValues={{name: '', email: '', phone: '',address: '', dob: '', password: ''}}
        validationSchema={
            Yup.object().shape({
                email: Yup.string().email().required('Email is required'),
                password: Yup.string().required('Password is required'),
            })
        }
        onSubmit={async (values, { setSubmitting }) => {
          var service = new AuthService();
          var result = await service.register(values);
            if (!result.success) {
                alert(result.errors[0]);
                return;
            }

            alert('register Success');
            // localStorage.setItem('token', res.data);
        }}
        >
            {({isSubmitting})=>(
                <Form>
                <div class="mb-3">
                  <label for="name" class="form-label">Name</label>
                  <Field type="text" name="name" id="name" class="form-control" placeholder="Name" aria-describedby="helpId"/>
                </div>
                <div class="mb-3">
                  <label for="email" class="form-label">Email</label>
                  <Field type="email" class="form-control" name="email" id="email" aria-describedby="emailHelpId" placeholder="abc@mail.com"/>
                  <ErrorMessage name="email" component="div" className='text-danger' />
                </div>
                <div class="mb-1 ">
                  <label for="phone" class="form-label">Phone No. </label>
                  <Field type="text" name="phone" id="phone" class="form-control"  aria-describedby="helpId"/>
                  </div>
                <div class="mb-3">
                  <label for="dob" class="form-label">DOB</label>
                  <Field type="date" name="dob" id="dob" class="form-control" aria-describedby="helpId"/>
                </div>
                <div class="mb-3">
                  <label for="address" class="form-label">Address</label>
                  <Field type="text" name="address" id="address" class="form-control" aria-describedby="helpId"/>
                </div>
                <div class="mb-3">
                  <label for="password" class="form-label">Password</label>
                  <Field type="password" class="form-control" name="password" id="passord" placeholder="Password"/>
                  <ErrorMessage name="password" component="div" className='text-danger' />
                  </div>
                  <div class="mb-3">
                  <label for="cpassword" class="form-label">Confirm Password</label>
                  <Field type="password" class="form-control" name="cpassword" id="cpassword" placeholder="Confirm Password"/>
                  <ErrorMessage name="cpassword" component="div" className='text-danger' />
                </div>
               
                <button type="submit" disabled={isSubmitting} class="btn btn-primary">Submit</button>
                </Form>

            )}
        
        </Formik>
    
    </div>
    
    </div>
    </div>

    </div>
    </div>
    );
  }
  
  export default Register;
  
/////css........................
//   .page{
//     width: 30vw;
//     margin-left: 33%;
//     /* background-color: white; */
// }

// .maindiv{
//   background-color:white;
//   width: 650px;
//   /* height: 800px; */
//   display: flex;
//   /* align-items: center; */
//   /* justify-content: center; */
//   margin-left: 300PX;
//   border-radius: 20%;

// }