import React from 'react';
import Form from 'react-bootstrap/Form';
import '../css/student.css'

import {
  MDBBtn,
  MDBContainer,
  MDBCard,
  MDBCardBody,
  MDBCardImage,
  MDBRow,
  MDBCol,
  MDBInput
//   MDBSelect
}
from 'mdb-react-ui-kit';

function Course() {
  return (
    <MDBContainer fluid>

      <MDBRow className='d-flex justify-content-center align-items-center'>

        <MDBCol lg='8'>

          <MDBCard className='my-5 rounded-3' style={{maxWidth: '600px'}}>
            <MDBCardImage src='https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/img3.webp' className='w-100 rounded-top'  alt="Sample photo"/>

            <MDBCardBody className='px-5'>

              <h3 className="mb-4 pb-2 pb-md-0 mb-md-5 px-md-2">Add Branch and Courses</h3>
              <MDBRow>
              <MDBCol md='6' className='mb-4'>
                <Form.Select aria-label="Default select example">
                    <option>Select Branch</option>
                    <option value="ME">ME</option>
                    <option value="EEE">EEE</option>
                    <option value="Civil">Civil</option>
                    </Form.Select>
                </MDBCol>
                <MDBCol md='6' className='mb-4'>
                <Form.Select aria-label="Default select example">
                    <option>Select Semester</option>
                    <option value="Semester1">Semester1</option>
                    <option value="Semester2">Semester2</option>
                    <option value="Semester3">Semester3</option>
                    </Form.Select>
                </MDBCol>
                </MDBRow>

                <MDBCol md='9'>
                  <MDBInput wrapperClass='datepicker mb-4' placeholder='Enter Course 1' id='form2' type='text'/>
                </MDBCol>
                <MDBCol md='9'>
                  <MDBInput wrapperClass='datepicker mb-4' placeholder='Enter Course 2' id='form2' type='text'/>
                </MDBCol>
                <MDBCol md='9'>
                  <MDBInput wrapperClass='datepicker mb-4' placeholder='Enter Course 3' id='form2' type='text'/>
                </MDBCol>

              <MDBBtn color='success' className='mb-4' size='lg'>Add</MDBBtn>

            </MDBCardBody>
          </MDBCard>

        </MDBCol>
      </MDBRow>

    </MDBContainer>
  );
}

export default Course;


///////css------
// .form
// {
//     width: 30vw;
//     margin-left: 33%;
// }
// .button
// {
//     width: 30vw;
// }
// .gradient-custom {
//   /* fallback for old browsers */
//   background: #65d9f6;

//   /* Chrome 10-25, Safari 5.1-6 */
//   background: -webkit-linear-gradient(to right bottom, rgba(246, 211, 101, 1), rgba(253, 160, 133, 1));

//   /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
//   background: linear-gradient(to right bottom, rgba(246, 211, 101, 1), rgba(253, 160, 133, 1))
// }
// body {
//     background-color: #8fc4b7;
//   }