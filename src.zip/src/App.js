import "./App.css";
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import StudentProfile from './Components/modules/StudentProfile'
import Bar from './Components/modules/Bar'
import Course from './Components/modules/Course'
import Register from './Components/modules/Register'


function App() {
  return (
    <Router>
      <Bar />
      <nav>
        <Link to = "/studentProfile">Student Profile</Link><br/>
        <Link to = "/course">Add Course</Link><br/>
        <Link to = "/register">Register</Link>
      </nav>
      <Routes>
        <Route path = "/studentProfile" element = {<StudentProfile/>} />
        <Route path = "/course" element = {<Course/>} />
        <Route path = "/register" element = {<Register/>} />
      </Routes>

    </Router>
  )

}

export default App;
